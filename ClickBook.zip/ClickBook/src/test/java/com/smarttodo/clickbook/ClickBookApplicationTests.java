package com.smarttodo.clickbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClickBookApplicationTests {

    @Test
    void contextLoads() {
    }

}
